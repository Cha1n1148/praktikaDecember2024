﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WeatherGraphApp
{
    public abstract class Sensor
    {
        protected List<(DateTime Timestamp, double Value)> _dataPoints; // Список данных с временными метками
        protected Random _random;

        public string Name { get; set; }
        public double MinValue { get; set; }
        public double MaxValue { get; set; }

        public Sensor(string name, double minValue, double maxValue)
        {
            Name = name;
            MinValue = minValue;
            MaxValue = maxValue;
            _dataPoints = new List<(DateTime, double)>();
            _random = new Random();
        }

        // Генерация случайных данных в заданном диапазоне
        public double GenerateRandomData()
        {
            return _random.NextDouble() * (MaxValue - MinValue) + MinValue;
        }

        // Добавление данных с текущей временной меткой
        public void AddData(double value)
        {
            _dataPoints.Add((DateTime.Now, value));
            if (_dataPoints.Count > 300)  // Ограничение на количество точек (примерно 5 минут данных)
                _dataPoints.RemoveAt(0);
        }

        // Получение среднего значения
        public double GetAverage() => _dataPoints.Average(dp => dp.Value);


        // Получение последних N данных
        public List<(DateTime, double)> GetRecentData(int count)
        {
            return _dataPoints.Skip(Math.Max(0, _dataPoints.Count - count)).ToList();
        }
    }
}
