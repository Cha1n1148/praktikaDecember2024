﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.Windows.Threading;

namespace WeatherGraphApp
{
    public class Graph
    {
        private Canvas _canvas;
        private List<(DateTime Timestamp, double Value)> _dataPoints;
        private Brush _lineColor;
        private double _minValue;
        private double _maxValue;
        private string _sensorType;
        private DispatcherTimer _timer;  // Таймер для обновлений
        private int _dataUpdateIntervalInSeconds;  // Интервал обновления данных в секундах

        // Конструктор
        public Graph(Canvas canvas, string sensorType, List<(DateTime, double)> dataPoints, Brush lineColor, int dataUpdateIntervalInSeconds = 5)
        {
            _canvas = canvas;
            _lineColor = lineColor;
            _dataPoints = dataPoints;
            _sensorType = sensorType;
            _dataUpdateIntervalInSeconds = dataUpdateIntervalInSeconds;

            // Устанавливаем масштаб для барометра и анемометра
            if (_sensorType == "Barometer")
            {
                _minValue = 950;  // Минимальное значение для барометра (гПа)
                _maxValue = 1050; // Максимальное значение для барометра (гПа)
            }
            else if (_sensorType == "Anemometer")
            {
                _minValue = 0;    // Минимальное значение для анемометра (м/с)
                _maxValue = 40;   // Максимальное значение для анемометра (м/с)
            }

            // Настройка таймера для обновлений
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromSeconds(_dataUpdateIntervalInSeconds);
            _timer.Tick += (sender, e) => UpdateGraph();
            _timer.Start();  // Стартуем таймер
        }

        // Метод отрисовки графика с осями
        public void Draw()
        {
            _canvas.Children.Clear();
            double canvasWidth = _canvas.ActualWidth;
            double canvasHeight = _canvas.ActualHeight;

            if (_dataPoints.Count == 0) return;

            // Получаем минимальное и максимальное время
            DateTime startTime = _dataPoints.First().Timestamp;
            DateTime endTime = _dataPoints.Last().Timestamp;
            double timeSpan = (endTime - startTime).TotalSeconds;

            // Преобразуем данные в точки для отображения на графике
            List<Point> points = new List<Point>();
            foreach (var dataPoint in _dataPoints)
            {
                // Масштабирование по оси X (время)
                double x = ((dataPoint.Timestamp - startTime).TotalSeconds / timeSpan) * canvasWidth;
                // Масштабирование по оси Y (значение показаний)
                double y = canvasHeight - ((dataPoint.Value - _minValue) / (_maxValue - _minValue)) * canvasHeight;

                // Ограничиваем точку по оси Y, чтобы она не выходила за пределы canvas
                y = Math.Max(0, Math.Min(y, canvasHeight));

                // Ограничиваем точку по оси X, чтобы она не выходила за пределы canvas
                x = Math.Max(0, Math.Min(x, canvasWidth));

                points.Add(new Point(x, y));
            }

            // Создаем и рисуем линию графика
            Polyline polyline = new Polyline
            {
                Stroke = _lineColor,
                StrokeThickness = 2,
                Points = new PointCollection(points)
            };

            _canvas.Children.Add(polyline);

            // Отрисовываем оси
            DrawAxes(canvasWidth, canvasHeight);

            // Отображаем метки осей
            DrawAxisLabels(canvasWidth, canvasHeight);
        }

        // Метод отрисовки осей X и Y
        private void DrawAxes(double canvasWidth, double canvasHeight)
        {
            // Рисуем ось X (горизонтальную)
            Line xAxis = new Line
            {
                X1 = 0,
                Y1 = canvasHeight,
                X2 = canvasWidth,
                Y2 = canvasHeight,
                Stroke = Brushes.Black,
                StrokeThickness = 1
            };
            _canvas.Children.Add(xAxis);

            // Рисуем ось Y (вертикальную)
            Line yAxis = new Line
            {
                X1 = 0,
                Y1 = 0,
                X2 = 0,
                Y2 = canvasHeight,
                Stroke = Brushes.Black,
                StrokeThickness = 1
            };
            _canvas.Children.Add(yAxis);
        }

        // Метод отрисовки меток на осях X и Y
        private void DrawAxisLabels(double canvasWidth, double canvasHeight)
        {
            // Оси X: отображаем метки по времени
            DateTime startTime = _dataPoints.First().Timestamp;
            DateTime endTime = _dataPoints.Last().Timestamp;
            double timeSpan = (endTime - startTime).TotalSeconds;
            double interval = timeSpan / 5; // Разделим по 5 интервалам для меток

            for (int i = 0; i <= 5; i++)
            {
                double x = (i * interval / timeSpan) * canvasWidth;

                DateTime timeLabel = startTime.AddSeconds(i * interval);
                TextBlock timeText = new TextBlock
                {
                    Text = timeLabel.ToString("HH:mm"),
                    FontSize = 10,
                    Foreground = Brushes.Black
                };

                // Размещение метки времени
                Canvas.SetLeft(timeText, x - timeText.ActualWidth / 2);
                Canvas.SetTop(timeText, canvasHeight + 5); // Под осью X
                _canvas.Children.Add(timeText);
            }

            // Оси Y: отображаем метки значений
            double valueInterval = (_maxValue - _minValue) / 5; // Разделим по 5 интервалам для меток

            for (int i = 0; i <= 5; i++)
            {
                double y = canvasHeight - (i * valueInterval / (_maxValue - _minValue)) * canvasHeight;

                TextBlock valueText = new TextBlock
                {
                    Text = (_minValue + i * valueInterval).ToString("F2"),
                    FontSize = 10,
                    Foreground = Brushes.Black
                };

                // Размещение метки значения
                Canvas.SetLeft(valueText, -valueText.ActualWidth - 5); // Левее оси Y
                Canvas.SetTop(valueText, y - valueText.ActualHeight / 2);
                _canvas.Children.Add(valueText);
            }
        }

        // Метод обновления данных и перерисовки графика
        public void UpdateData(List<(DateTime Timestamp, double Value)> newData)
        {
            _dataPoints = newData;
            Draw();  // Перерисовываем график с новыми данными
        }

        // Метод для обновления графика по таймеру
        private void UpdateGraph()
        {
            // Здесь можно добавить логику для получения новых данных, например, от датчика
            // Для примера я добавлю случайные данные
            var newDataPoint = (DateTime.Now, new Random().NextDouble() * (_maxValue - _minValue) + _minValue);
            _dataPoints.Add(newDataPoint);

            // Ограничиваем количество данных, например, до 50 точек
            if (_dataPoints.Count > 50)
                _dataPoints.RemoveAt(0);

            Draw();  // Перерисовываем график
        }
    }
}
