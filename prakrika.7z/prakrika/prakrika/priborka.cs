﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherGraphApp
{
    public class Barometer : Sensor
    {
        public Barometer() : base("Барометр", 950, 1050) { }
    }

    public class Anemometer : Sensor
    {
        public Anemometer() : base("Анемометр", 0, 40) { }
    }
}
