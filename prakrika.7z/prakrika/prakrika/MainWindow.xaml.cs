﻿using System.Windows;
using System.Windows.Media;
using WeatherGraphApp;

namespace prakrika
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Barometer _barometer;
        private Anemometer _anemometer;
        private Graph _barometerGraph;
        private Graph _anemometerGraph;
        private Task _updateTask;  // Ссылка на фоновую задачу для обновления данных
        private bool _isUpdating;  // Флаг для отслеживания состояния обновлений
        public MainWindow()
        {
            InitializeComponent();
            _barometer = new Barometer();
            _anemometer = new Anemometer();

            // Инициализация графиков
            _barometerGraph = new Graph(chartCanvas, "Barometer", _barometer.GetRecentData(300), Brushes.Blue);
            _anemometerGraph = new Graph(chartCanvas, "Anemometer", _anemometer.GetRecentData(300), Brushes.Red);

            _isUpdating = false;  // Изначально обновления остановлены
        }
        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            if (!_isUpdating)
            {
                _isUpdating = true; // Включаем обновления
                _updateTask = Task.Run(UpdateData); // Запускаем обновления данных в фоновом режиме
            }
        }
        private void ShowAverageGraphButton_Click(object sender, RoutedEventArgs e)
        {
            // Получаем среднее значение для всех данных графика
            double barometerAverageGraph = _barometer.GetAverage();
            double anemometerAverageGraph = _anemometer.GetAverage();

            // Выводим среднее по графику в TextBox
            averageDataText.Text = $"Среднее по графику:\nБарометр: {barometerAverageGraph:F2} гПа\nАнемометр: {anemometerAverageGraph:F2} м/с";
        }

        // Обработчик события кнопки "Стоп"
        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            if (_isUpdating)
            {
                _isUpdating = false; // Останавливаем обновления
                _updateTask?.Wait(); // Ожидаем завершения фона
            }
        }

        // Фоновая задача для обновления данных
        private async Task UpdateData()
        {
            while (_isUpdating)
            {
                // Генерация случайных данных для барометра и анемометра
                double barometerReading = _barometer.GenerateRandomData();
                double anemometerReading = _anemometer.GenerateRandomData();

                // Добавление новых данных
                _barometer.AddData(barometerReading);
                _anemometer.AddData(anemometerReading);

                // Обновление графиков
                Dispatcher.Invoke(() =>
                {
                    // Обновляем графики для барометра и анемометра
                    _barometerGraph.UpdateData(_barometer.GetRecentData(300));
                    _anemometerGraph.UpdateData(_anemometer.GetRecentData(300));

                    // Отображение статистики
                    UpdateStatistics();
                });

                // Задержка между обновлениями данных (1 секунда)
                await Task.Delay(1000);
            }
        }

        // Метод для обновления статистики
        private void UpdateStatistics()
        {
            // Получение статистики для барометра
            var barometerStats = GetStatistics(_barometer);
            // Получение статистики для анемометра
            var anemometerStats = GetStatistics(_anemometer);

            // Обновление UI с статистикой
            currentDataText.Text = $"Барометр: {_barometer.GetAverage():F2} гПа\nАнемометр: {_anemometer.GetAverage():F2} м/с";
            averageDataText.Text = $"Среднее:\nБарометр: {barometerStats.Average:F2} гПа\nАнемометр: {anemometerStats.Average:F2} м/с";
        }

        // Метод для получения статистики (теперь только среднее значение)
        private (double Average, double Placeholder) GetStatistics(Sensor sensor)
        {
            var avg = sensor.GetAverage();

            // Возвращаем кортеж с двумя элементами: среднее значение и просто 0 как Placeholder
            return (avg, 0.0);  // Второй элемент — просто 0.0, это можно заменить на любое другое значение
        }
    }
}


    


